#!/bin/bash
if [ "$1" = "-help" ]; then
echo "Uso: backup_full.sh ORIGEN DESTINO"
exit 0
fi
if [ $# -ne 2 ]; then
echo "Error: debe indicar origen y destino"
exit 1
fi
ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
tar -czf "$DESTINO/${NOMBRE}_bkp_$FECHA.tar.gz" "$ORIGEN"
echo "Backup generado correctamente"