history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
hostname
cat /etc/hostname
cat /etc/debian_version
ping 8.8.8.8
ping google.com
cp /etc/apt/source.list /etc/apt/source.list.bak
nano /etc/apt/source.list
cp /etc/apt/sources.list /etc/apt/sources.list.bak
vi /etc/apt/sources.list
apt-get update
vi /etc/apt/sources.list
apt-get update
apt-get updagrade -y
apt-get upgrade -y
lsblk
grub-install /dev/sda
update-grub
dpkg --configure -a
apt-get full-upgrade -y
apt-get autoremove -y
reboot
exit
cat /etc/debian_version
apt-get install opensh-sever -y
apt-get install openssh-server -y
systemctl status ssh
systemctl enable ssh
systemctl is-enabled ssh
ls -l /root
tar -xzvf /root/Material_Adicional_TPVMCA.tar.gz -C /root
ls -l /root
mkdir -p /root/.ssh
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
chown -R root:root /root.ssh
chown -R root:root /root/.ssh
ls -l /root/.ssh
vi /etc/ssh/sshd_config
systemctl resrtart ssh
systemctl restart ssh
systemctl status ssh
chmod 600 /root/Material_Adicional_TPVMCA/clave_privda.txt
ls -l /root/Material_Adicional_TPVMCA
chmod 600 /root/Material_Adicional_TPVMCA/clave_privada.txt
ssh -i /root/Material_Adicional_TPVMCA/clave_privada.txt root@localhost
apt-get install apache2 php libapache2-mod-php php-mysql -y
systemctl status apache2
systemctl enable apache2
systemctl is-enabled apache2
php -v
apt-get install mariadb-server -y
systemctl status mariadb
systemctl enable mariadb
systemctl is-enabled mariadb
ls -l /root/Material_Adicional_TPVMCA/db.sql
mysql < /root/Material_Adicional_TPVMCA/db.sql
mysql -e "SHOW DATABASES;"
ip a
ip route
poweroff
vi /etc/network/interfaces
systemctl restart networking
ip a
ping 192.168.0.1
ping google.com
poweroff
lsblk
fdisk /dev/sdc
lsblk
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
blkid
vi /etc/fstab
mount -a
vi /etc/fstab
systemctl daemon-reload
mount -a
df -h
cp /root/Material_Adicional_TPVMC/logo.png /www_dir/
cp /root/Material:Adicional_TPVMCA/index.php /www_dir/
cp /root/Material_Adiconal_TPVMCA/index.php /www_dir/
cp /root/Material_Adicional_TPVMCA/index.php /www_dor/
cp /root/Material_Adicional_TPVMCA/index.php /www_dir/
cp /root/Material_Adicional_TPVMCA/logo.png /www_dir/
ls -l /www_dir
vi /etc/apache2/sities-avaible/000-default.conf
vi /etc/apache2/sities-available/000-default.conf
vi /etc/apache2/sites-available/000-default.conf
vi /etc/apache2/apache2.conf
systemctl restart apache2
systemctl status apache2
apache2ctl configtest
cat /proc/partitions > /opt/particion
cat /opt/particion
df -h
ls -l /www_dir
poweroff
